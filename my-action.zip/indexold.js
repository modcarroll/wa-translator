const AssistantV2 = require('ibm-watson/assistant/v2');
const { IamAuthenticator } = require('ibm-watson/auth');
const LanguageTranslatorV3 = require('ibm-watson/language-translator/v3');

function main(params) {

  let wa_apikey = "0AANVhOG9gstivewHA5FaSqacZahk4256ImdtWPOcAK0";
  let wa_url = "https://gateway.watsonplatform.net/assistant/api";
  let wa_version = "2020-04-01";
  let assistantId = "99ba5780-4632-4323-b27c-b25f9220f948";

  let lt_apikey = "eFOaOyiRXRggUTG0JPwzMICuO4JLiy5guQo_ip24ZFv9";
  let lt_url = "https://gateway.watsonplatform.net/language-translator/api";
  let lt_version = "2018-05-01";

  const authenticatorWA = new IamAuthenticator({apikey: wa_apikey});
  const authenticatorLT = new IamAuthenticator({apikey: lt_apikey});

  const assistant = new AssistantV2({
    version: wa_version,
    authenticator: authenticatorWA,
    url: wa_url,
  });

  const languageTranslator = new LanguageTranslatorV3({
    version: lt_version,
    authenticator: authenticatorLT,
    url: lt_url,
  });

  let sessionId = "";
  // assign variables from input parameters, passed from Watson Assistant
  sessionId = params.session_id ? params.session_id : '';
  userUtter = params.user_utterance;

  // will need to remove this section later, assume sessionId is always given
  if(!sessionId) {
    assistant.createSession({
      assistantId: assistantId
    })
      .then(res => {
        sessionId = res.result.session_id;

        language = params.language;

        console.log("Input: ", userUtter);

        const translateParams = {
          text: userUtter,
          modelId: 'es-en',
        };

        // First get user utterance, send to LT to translate to English
        languageTranslator.translate(translateParams)
        .then(translationResult => {
          // console.log(JSON.stringify(translationResult.result.translations[0].translation, null, 2));

          let englishTransl = translationResult.result.translations[0].translation;

          console.log("English input: ", englishTransl);

          // Send English translation to WA
          assistant.message({
            assistantId: assistantId,
            sessionId: sessionId,
            input: {
              'message_type': 'text',
              'text': englishTransl
              }
          }).then(res => {

            // Get resonse from WA
            console.log("English output: ", res.result.output.generic[0].text);

            const translateParams = {
              text: res.result.output.generic[0].text,
              modelId: 'en-es',
            };
            // Send response to LT
            languageTranslator.translate(translateParams)
            .then(translationResult => {
              console.log("Output translation: ", translationResult.result.translations[0].translation);
              return{"message":translationResult.result.translations[0].translation};
            })
          })
          .catch(err => {
            console.log(err);
          });

        })
        .catch(err => {
          console.log('error:', err);
          return {"error": "An error has occured. Please try again."};
        });
      })
      .catch(err => {
        console.log(err);
      });
  }

  // will need to craft en-es, es-en, etc. from this
}

// remove before uploading to CF
// main({sessionId: "", userUtter: "Qué puedes hacer", language: ""})

exports.main=main;

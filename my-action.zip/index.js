const AssistantV2 = require('ibm-watson/assistant/v2');
const { IamAuthenticator } = require('ibm-watson/auth');
const LanguageTranslatorV3 = require('ibm-watson/language-translator/v3');

function main(params) {

  let wa_apikey = "0AANVhOG9gstivewHA5FaSqacZahk4256ImdtWPOcAK0";
  let wa_url = "https://gateway.watsonplatform.net/assistant/api";
  let wa_version = "2020-04-01";
  let assistantId = "99ba5780-4632-4323-b27c-b25f9220f948";

  let lt_apikey = "eFOaOyiRXRggUTG0JPwzMICuO4JLiy5guQo_ip24ZFv9";
  let lt_url = "https://gateway.watsonplatform.net/language-translator/api";
  let lt_version = "2018-05-01";

  let originalInput = "";
  let translatedInput = "";
  let originalOutput = "";
  let translatedOutput = "";

  const authenticatorWA = new IamAuthenticator({apikey: wa_apikey});
  const authenticatorLT = new IamAuthenticator({apikey: lt_apikey});

  const assistant = new AssistantV2({
    version: wa_version,
    authenticator: authenticatorWA,
    url: wa_url,
  });

  const languageTranslator = new LanguageTranslatorV3({
    version: lt_version,
    authenticator: authenticatorLT,
    url: lt_url,
  });

  let sessionId = "";
  // assign variables from input parameters, passed from Watson Assistant
  sessionId = params.session_id ? params.session_id : '';
  userUtter = params.user_utterance;
  originalInput = userUtter;
  language = params.language;

  const translateParams = {
    text: userUtter,
    modelId: language + "-en",
  };

  return new Promise((resolve, reject) => {
    assistant.createSession({
      assistantId: assistantId
    }).then(res => {
        sessionId = res.result.session_id;

        language = params.language;

        console.log("Input: ", userUtter);

        return languageTranslator.translate(translateParams)
    }).then(function (translationResult) {

      let englishTransl = translationResult.result.translations[0].translation;
      console.log("English input: ", englishTransl);
      translatedInput = englishTransl;

       return assistant.message({
         assistantId: assistantId,
         sessionId: sessionId,
         input: {
           'message_type': 'text',
           'text': englishTransl
           }
       });
    }).then(function(res) {
      console.log("English output: ", res.result.output.generic[0].text);
      originalOutput = res.result.output.generic[0].text;

      const translateParams = {
        text: res.result.output.generic[0].text,
        modelId: 'en-' + language,
      };

       return languageTranslator.translate(translateParams);

     }).then(function(translationResult) {
       console.log("Output translation: ", translationResult.result.translations[0].translation);
       translatedOutput = translationResult;
       // return{"message":translationResult.result.translations[0].translation};
       resolve({"message":translationResult.result.translations[0].translation, "originalInput": originalInput, "translatedInput": translatedInput, "originalOutput": originalOutput, "translatedOutput": translatedOutput});
     }).catch(function (err) {
       console.log("****error: ", err);
     });
   });
}

exports.main=main;
// main({sessionId: "", user_utterance: "¿Que puedes hacer?", language: "es"});
